export enum ReservationStatus {
    ACTIVE = 'active',
    CANCELED = 'canceled',
    CHECKED_OUT = 'checked_out',
  }
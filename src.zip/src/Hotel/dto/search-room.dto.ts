// dto/search-room.dto.ts
import { IsUUID, IsDateString } from 'class-validator';

export class SearchRoomDto {
  @IsUUID()
  roomId: string;

  @IsDateString()
  checkIn: string;

  @IsDateString()
  checkOut: string;
}

export class SearchRoomDto {
    roomId: string;
    checkIn: string; 
    checkOut: string;
  }
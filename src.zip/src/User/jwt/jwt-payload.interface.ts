export interface JwtPayload {
    phoneNumber: string;
    sub: string; 
  }